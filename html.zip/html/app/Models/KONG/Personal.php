<?php

namespace App\Models\KONG;

use Illuminate\Database\Eloquent\Model; 

class Personal extends Model
{
	protected $fillable = ['id', 'userId', 'fname', 'lname', 'created_at', 'updated_at', 'id', 'userId', 'users'];

}