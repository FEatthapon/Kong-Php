<?php

namespace App\Models\KONG;

use Illuminate\Database\Eloquent\Model; 

class User extends Model
{
	protected $fillable = ['id', 'username', 'password', 'enable', 'created_at', 'updated_at', 'id'];

}