<?php

namespace App\Http\Controllers;

use App\Models\KONG\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class AuthorController extends Controller {

    public function test(Request $request)
    : JsonResponse {

        return response()->json(User::all());
    }
}
